package com.yourname.subgenius.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.yourname.subgenius.ui.AppViewModel
import com.yourname.subgenius.ui.screens.CustomizeScreen
import com.yourname.subgenius.ui.screens.DownloadScreen
import com.yourname.subgenius.ui.screens.ExtractScreen
import com.yourname.subgenius.ui.screens.HomeScreen
import com.yourname.subgenius.ui.screens.ProjectsScreen
import com.yourname.subgenius.ui.screens.TranslateScreen
import com.yourname.subgenius.ui.screens.VideoScreen

object Routes {
    const val HOME = "home"
    const val VIDEO = "video"
    const val EXTRACT = "extract"
    const val TRANSLATE = "translate"
    const val CUSTOMIZE = "customize"
    const val PROJECTS = "projects"
    const val DOWNLOAD = "download"
}

@Composable
fun NavGraph(navController: NavHostController, appViewModel: AppViewModel, modifier: Modifier = Modifier) {
    NavHost(navController, startDestination = Routes.HOME, modifier = modifier) {
        composable(Routes.HOME) {
            HomeScreen(
                onPickVideo = { uri -> appViewModel.setVideo(uri); navController.navigate(Routes.VIDEO) },
                onOpenProjects = { navController.navigate(Routes.PROJECTS) },
                onOpenDownload = { navController.navigate(Routes.DOWNLOAD) }
            )
        }
        composable(Routes.VIDEO) {
            VideoScreen(
                appViewModel = appViewModel,
                onBack = { navController.popBackStack() },
                onExtract = { navController.navigate(Routes.EXTRACT) },
                onTranslate = { navController.navigate(Routes.TRANSLATE) },
                onCustomize = { navController.navigate(Routes.CUSTOMIZE) }
            )
        }
        composable(Routes.EXTRACT) {
            ExtractScreen(
                appViewModel = appViewModel,
                onBack = { navController.popBackStack() },
                onDone = { navController.navigate(Routes.TRANSLATE) }
            )
        }
        composable(Routes.TRANSLATE) {
            TranslateScreen(
                appViewModel = appViewModel,
                onBack = { navController.popBackStack() },
                onDone = { navController.navigate(Routes.CUSTOMIZE) }
            )
        }
        composable(Routes.CUSTOMIZE) {
            CustomizeScreen(appViewModel = appViewModel, onBack = { navController.popBackStack() })
        }
        composable(Routes.PROJECTS) { ProjectsScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.DOWNLOAD) { DownloadScreen(onBack = { navController.popBackStack() }) }
    }
}
