# عبقري الترجمة (SubGenius)

## البناء
- محلياً: افتح المشروع في Android Studio (Ladybug أو أحدث) ثم Run. لا يوجد gradlew في الحزمة؛ Android Studio ينشئ الـ wrapper تلقائياً.
- GitHub Actions: ارفع المشروع ثم شغّل workflow. يُنتج APK debug دائماً.
  للتوقيع أضف Secrets: KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD.

## قبل النشر
1. غيّر `com.yourname.subgenius` إلى اسم حزمتك.
2. إن فشل تحميل `dev.ffmpegkit-maintained:ffmpeg-kit-full` ضع ملف .aar داخل `app/libs/`.
3. تحقق من روابط نماذج Vosk في `VoskModelDownloader.kt` (alphacephei.com/vosk/models).
4. التطبيق مجاني بالكامل: لا فوترة ولا اشتراكات.
5. الخط العربي: يُستخدم خط النظام تلقائياً. لخط محدد ضع ملف .ttf في `app/src/main/assets/fonts/`.
