package com.yourname.subgenius.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class Project(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val videoUri: String,
    /** Uri الفيديو الناتج في المعرض (content://) */
    val outputPath: String? = null,
    val sourceLang: String = "ar",
    val targetLang: String = "en",
    val status: String = "pending",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
