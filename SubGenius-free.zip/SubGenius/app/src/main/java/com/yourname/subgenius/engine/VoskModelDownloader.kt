package com.yourname.subgenius.engine

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

data class VoskModelInfo(val lang: String, val label: String, val url: String, val dirName: String, val size: String)

object VoskModelDownloader {
    // تحقق من الروابط والأحجام في https://alphacephei.com/vosk/models
    val models = listOf(
        VoskModelInfo("ar", "العربية", "https://alphacephei.com/vosk/models/vosk-model-small-ar-tn-0.1-linto.zip", "vosk-ar", "~160MB"),
        VoskModelInfo("en", "English", "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip", "vosk-en", "~40MB")
    )

    fun info(lang: String): VoskModelInfo? = models.firstOrNull { it.lang == lang }

    fun getModelPath(context: Context, lang: String): String? {
        val m = info(lang) ?: return null
        return findModelDir(File(context.filesDir, m.dirName))?.absolutePath
    }

    private fun findModelDir(dir: File): File? {
        if (!dir.exists()) return null
        if (File(dir, "conf").exists() || File(dir, "am").exists()) return dir
        dir.listFiles()?.forEach { c ->
            if (c.isDirectory && (File(c, "conf").exists() || File(c, "am").exists())) return c
        }
        return null
    }

    suspend fun downloadAndUnzip(context: Context, lang: String, onProgress: (Int) -> Unit): Result<String> =
        withContext(Dispatchers.IO) {
            val m = info(lang) ?: return@withContext Result.failure(Exception("لغة غير مدعومة"))
            try {
                val zipFile = File(context.cacheDir, "vosk_${m.lang}.zip")
                val conn = URL(m.url).openConnection() as HttpURLConnection
                conn.connectTimeout = 20000; conn.readTimeout = 30000
                conn.connect()
                if (conn.responseCode != 200) throw Exception("HTTP ${conn.responseCode} — تحقق من رابط النموذج")
                val total = conn.contentLengthLong
                var downloaded = 0L
                conn.inputStream.use { input ->
                    FileOutputStream(zipFile).use { output ->
                        val buf = ByteArray(8192); var n: Int
                        while (input.read(buf).also { n = it } != -1) {
                            output.write(buf, 0, n); downloaded += n
                            if (total > 0) onProgress(((downloaded * 100) / total).toInt().coerceIn(0, 99))
                        }
                    }
                }
                val target = File(context.filesDir, m.dirName)
                if (target.exists()) target.deleteRecursively()
                target.mkdirs()
                ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
                    var e = zis.nextEntry
                    while (e != null) {
                        val out = File(target, e.name)
                        if (!out.canonicalPath.startsWith(target.canonicalPath + File.separator))
                            throw SecurityException("unsafe path")
                        if (e.isDirectory) out.mkdirs() else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { fos ->
                                val b = ByteArray(8192); var k: Int
                                while (zis.read(b).also { k = it } != -1) fos.write(b, 0, k)
                            }
                        }
                        zis.closeEntry(); e = zis.nextEntry
                    }
                }
                zipFile.delete()
                val actual = findModelDir(target) ?: throw Exception("بنية النموذج غير متوقعة")
                onProgress(100)
                Result.success(actual.absolutePath)
            } catch (e: Exception) { Result.failure(e) }
        }
}
